/* ==========================================================
   Hearth — API client
   Thin wrapper around fetch so every page calls the backend the
   same way: attaches the JWT automatically, throws a readable
   error message instead of a raw Response object, and redirects
   to login if the token's expired or missing.
   ========================================================== */

const API_BASE = 'http://localhost:5000/api';

const Api = {
  getToken() {
    return localStorage.getItem('hearth_token');
  },

  setSession({ token, userId, fullName, email, role }) {
    localStorage.setItem('hearth_token', token);
    localStorage.setItem('hearth_user', JSON.stringify({ userId, fullName, email, role }));
  },

  getUser() {
    const raw = localStorage.getItem('hearth_user');
    return raw ? JSON.parse(raw) : null;
  },

  clearSession() {
    localStorage.removeItem('hearth_token');
    localStorage.removeItem('hearth_user');
  },

  isLoggedIn() {
    return !!this.getToken();
  },

  // every protected page should call this at the top of its script
  requireAuth() {
    if (!this.isLoggedIn()) {
      window.location.href = 'index.html';
    }
  },

  requireRole(roles) {
    const user = this.getUser();
    if (!user || !roles.includes(user.role)) {
      window.location.href = 'dashboard.html';
    }
  },

  async request(path, { method = 'GET', body = null, auth = true } = {}) {
    const headers = { 'Content-Type': 'application/json' };
    if (auth) {
      const token = this.getToken();
      if (token) headers['Authorization'] = `Bearer ${token}`;
    }

    let response;
    try {
      response = await fetch(`${API_BASE}${path}`, {
        method,
        headers,
        body: body ? JSON.stringify(body) : undefined
      });
    } catch (networkErr) {
      throw new Error('Could not reach the server. Is the API running on localhost:5000?');
    }

    // token expired or invalid - send back to login rather than showing a cryptic error
    if (response.status === 401 && auth) {
      this.clearSession();
      window.location.href = 'index.html';
      return;
    }

    if (!response.ok) {
      const text = await response.text();
      throw new Error(text || `Request failed (${response.status})`);
    }

    const contentType = response.headers.get('content-type') || '';
    if (contentType.includes('application/json')) {
      return response.json();
    }
    return null;
  },

  // ---- auth ----
  register(data) { return this.request('/auth/register', { method: 'POST', body: data, auth: false }); },
  login(data) { return this.request('/auth/login', { method: 'POST', body: data, auth: false }); },

  // ---- subscriptions ----
  getMySubscriptions() { return this.request('/subscriptions/mine'); },

  // ---- tickets ----
  submitTicket(data) { return this.request('/tickets', { method: 'POST', body: data }); },
  getMyTickets() { return this.request('/tickets'); },
  getTicket(id) { return this.request(`/tickets/${id}`); },
  getQueue(params = {}) {
    const query = new URLSearchParams(params).toString();
    return this.request(`/tickets/queue${query ? `?${query}` : ''}`);
  },
  updateTicketStatus(id, status) {
    return this.request(`/tickets/${id}/status`, { method: 'PATCH', body: { status } });
  },
  getComments(id) { return this.request(`/tickets/${id}/comments`); },
  addComment(id, message) {
    return this.request(`/tickets/${id}/comments`, { method: 'POST', body: { message } });
  }
};
