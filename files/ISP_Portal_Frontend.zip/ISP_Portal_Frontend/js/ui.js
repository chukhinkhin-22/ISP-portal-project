/* ==========================================================
   Hearth — shared UI helpers
   Tag rendering and date formatting live here once, so the
   color language (moss/gold/terracotta) stays consistent across
   every page instead of being redefined per-file.
   ========================================================== */

const Ui = {
  escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str ?? '';
    return div.innerHTML;
  },

  formatDate(isoString) {
    if (!isoString) return '—';
    const d = new Date(isoString);
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) +
      ' · ' + d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
  },

  // priority: Low/Medium/High -> calm/active/urgent
  priorityTag(priority) {
    const map = { Low: 'moss', Medium: 'gold', High: 'terracotta' };
    const color = map[priority] || 'neutral';
    return `<span class="tag tag-${color}"><span class="tag-dot"></span>${priority}</span>`;
  },

  // ticket status: Open is the one that needs eyes, Resolved is the calm end state
  statusTag(status) {
    const map = { Open: 'terracotta', In_Progress: 'gold', Resolved: 'moss', Closed: 'neutral' };
    const color = map[status] || 'neutral';
    const label = status.replace('_', ' ');
    return `<span class="tag tag-${color}"><span class="tag-dot"></span>${label}</span>`;
  },

  departmentTag(department) {
    const label = (department || 'Unassigned').replace(/_/g, ' ');
    return `<span class="tag tag-neutral">${label}</span>`;
  },

  // node/connection status -> same three-color language again
  nodeStatusPulse(status) {
    const map = { Active: 'moss', Maintenance: 'gold', Offline: 'terracotta' };
    return map[status] || 'neutral';
  },

  initials(fullName) {
    if (!fullName) return '?';
    const parts = fullName.trim().split(/\s+/);
    return parts.length > 1 ? (parts[0][0] + parts[1][0]).toUpperCase() : parts[0].slice(0, 2).toUpperCase();
  },

  // fills in the navbar's user name + role, wires the logout button,
  // and shows the staff queue link only for Staff/Admin
  initNav() {
    const user = Api.getUser();
    if (!user) return;

    const nameEl = document.getElementById('navUserName');
    const roleEl = document.getElementById('navUserRole');
    const avatarEl = document.getElementById('navUserAvatar');
    if (nameEl) nameEl.textContent = user.fullName;
    if (roleEl) roleEl.textContent = user.role;
    if (avatarEl) avatarEl.textContent = this.initials(user.fullName);

    const staffLink = document.getElementById('staffQueueLink');
    if (staffLink && !['Staff', 'Admin'].includes(user.role)) {
      staffLink.style.display = 'none';
    }

    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', () => {
        Api.clearSession();
        window.location.href = 'index.html';
      });
    }
  }
};
